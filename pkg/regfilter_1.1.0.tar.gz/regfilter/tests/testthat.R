library(testthat)
library(regfilter)

test_check("regfilter")
