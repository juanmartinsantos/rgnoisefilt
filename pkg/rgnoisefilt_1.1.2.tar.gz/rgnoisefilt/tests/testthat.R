library(testthat)
library(rgnoisefilt)

test_check("rgnoisefilt")
