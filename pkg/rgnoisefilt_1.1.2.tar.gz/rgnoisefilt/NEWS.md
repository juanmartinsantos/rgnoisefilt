# rgnoisefilt 1.0

* This is the first version of the rgnoisefilt package.

# rgnoisefilt 1.0.1

* Copyright has been updated and additional tests included.

# rgnoisefilt 1.0.2

* Fixed some issues on M1mac and noLD.

# rgnoisefilt 1.0.3

* Minor modifications.

# rgnoisefilt 1.1.0

* New noise filters have been added. Additionally, a plot function has been integrated to display the filtering process.

# rgnoisefilt 1.1.1

* Minor modifications.

# rgnoisefilt 1.1.2

* Minor modifications. Some functions have been added to remove dependencies.